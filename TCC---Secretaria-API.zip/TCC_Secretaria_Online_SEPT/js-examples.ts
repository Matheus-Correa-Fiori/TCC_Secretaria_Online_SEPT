
// MONTAR UM OBJETO TS

//   const login = {
//     token,
//     user: {
//       id: user.usr_id,
//       name: user.usr_name + ' ' + user.usr_last_name,
//       email: user.usr_email,
//       role: user.usr_role,
//       company: user.usr_company,
//       picture: user.usr_picture,
//       profileCompleted: user.usr_profile_completed,
//       doubleVerify: user.usr_doubleVerify,
//       theme: user.usr_theme,
//       language: user.usr_language
//     }
//   };


