/**
 * App Calendar Events
 */

'use strict';

// var date = new Date();
// var nextDay = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
// // prettier-ignore
// var nextMonth = date.getMonth() === 11 ? new Date(date.getFullYear() + 1, 0, 1) : new Date(date.getFullYear(), date.getMonth() + 1, 1);
// // prettier-ignore
// var prevMonth = date.getMonth() === 11 ? new Date(date.getFullYear() - 1, 0, 1) : new Date(date.getFullYear(), date.getMonth() - 1, 1);



var events = [

  {
    id: 44,
    url: '',
    title: 'Testeeeee',
    start: '2023-09-29T07:30:00',
    end: '2023-09-29T12:30:00',
    allDay: false,
    extendedProps: {
      calendar: 'Business'
    }
  }
 
];
