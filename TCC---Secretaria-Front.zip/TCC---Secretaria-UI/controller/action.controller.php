<?php
namespace API\Controller;
use API\Controller\DefaultController;

class Action extends DefaultController {
    // public function newOrder(string $username, string $pin, int $id_item) {
    //     $client = new \GuzzleHttp\Client();
    //     $response = $client->request('POST', Config::API_URL . "purchases/new", [
    //         'headers' => [
              
    //         ],
    //         "json" => [
    //             "username" => $username,
    //             "pin" => $pin,
    //             "id_item" => $id_item,
    //         ]
    //     ]);

    //     return json_decode($response->getBody(), true);
    // }
}
