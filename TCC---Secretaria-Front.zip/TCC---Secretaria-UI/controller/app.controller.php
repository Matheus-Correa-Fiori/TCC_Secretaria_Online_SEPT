<?php
namespace API\Controller;
class App {
    const DEV_ENV = true;
}
